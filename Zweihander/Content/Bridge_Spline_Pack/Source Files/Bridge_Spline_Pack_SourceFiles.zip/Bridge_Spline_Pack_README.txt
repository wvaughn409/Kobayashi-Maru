Substance Materials Documentation

Requires the substance plugin be installed. When that's done, open UE4, go to Edit > Plugins and enable the Substance plugin. 

Next make sure that the GPU Engine is enabled. This can be done by going to Edit -> Project Settings -> Scroll down to the bottom to Plugins/Substance -> Under 'Cooking', change the Substance Engine dropdown to GPU Engine.

Now restart UE4 and then you should be good to go.


BLUEPRINT USE TUTORIAL VIDEO: https://streamable.com/8xkv2

======================================================================
BLUEPRINT INTRUCTIONS
======================================================================

Collisions: Generates player collision for the bridge. LEAVE OFF UNTIL THE END OR YOU WILL GET LAG.

----------------------------------------------------------------------
Mesh Placement
----------------------------------------------------------------------


Mesh Spacing: Controls how far the spline will stretch a body mesh before adding another one.

Random Seed: randomizes the placement of bridge body meshes.

Alternate Placement: Turn this on if you want the spline to just use 2 body meshes and alternate the placement between the two.

Alternate Frequency: sets the how it alternates between the first two body meshes.

-----------------------------------------------------------------------
Spline Body
-----------------------------------------------------------------------
Mesh Array: Hit the + symbol to set how many bridge body meshes you want to use.

Spline Material Array: Hit the + symbol to set how many material slots you need according to the number of material slots listed when you open the mesh viewer of the meshes that you want to use. 

Next, select the materials you want to use and plug them in.

-------------------------------------------------------------------------
Spline Ends 
-------------------------------------------------------------------------
If you want end meshes on your bridge spline, load them in here and click the check mark boxes to enable them.


===========================================================================
===========================================================================

-------------------------------------------------------------------
SUBSTANCE MATERIAL CONTROLS DOCUMENTATION.
-------------------------------------------------------------------

Substance material Controls can be found in the Textures Folder. They are the red colored files and each one effects the corresponding textures of the same name.

It is reccomended to drop the substance material down to a lower resolution for faster responce time to changes made with the controls. When you are satisfied bring the resolution back up to your desired output.

===================================================================
ROPE MATERIAL
===================================================================

Normal Intensity: Controls the strength of the normal map.


Color Group

	Saturation: controls the color saturation of the rope color.

	Lightness: Controls the brightness of the rope color.

Dirt Group
	
	Dirt Saturation Controls the color saturation of the dirt color.
	
	Dirt Lightness: Controls the lightness of the dirt color.

	Dirt Level: Controls the amount of dirt that covers the rope material.

	Dirt Contrast: Secondary dirt spread control that works in tandem with Dirt Level. 

=======================================================================
MODULAR COBBLESTONE 
=======================================================================


Color

---------------------------------------------------------------------------------

3 color pickers for the cobblestones for color variation.

1 color picker used for circular and fishscale patterns.

1 color picker for the dirt between the cobblestones.

1 color picker for the dirt on top of the cobblestones.

Cobblestone_Highlight_Lightness: Controls the lightness of the highlight on the cobblestones.

Cobblestone_Highlight_Range: Controls how much the highlight color covers the cobblestones.

Cobblestone_Highlight_Contrast: Contrast control for the cobblestone highlight.

Cobblestone_Secondary_Highlight_Opacity: Controls the opacity of a secondary highlight for the cobblestones that's layered under the primary highlight.

---------------------------------------------------------------------------------
Pattern
---------------------------------------------------------------------------------
Pattern_Switch: Switches between 3 cobblestone patterns. Strait brick pattern, circular pattern, and a fishscale pattern.

Cobblestone_Shape_Switch: Switch between 3 base shapes for the cobblestones. 

---------------------------------------------------------------------------------
Circular (circular pattern and fishscale pattern)
---------------------------------------------------------------------------------

Circular_Pattern_Stone_Scale: Controls the size of the cobblestones for the circular and fishscale patterns. 

Circular/Fishscale_Pattern_scale:Toggle that changes between two versions for the ciruclar and fan patterns. The 2nd version of both contains more cobblestones in the patterns.

Ring_Color_Pattern_Switch: Switch that switches between color patterns for the circular and fishscale cobblestone patterns.

---------------------------------------------------------------------------------
Straight Pattern
---------------------------------------------------------------------------------

Number_X and Number_Y: Sets the number of cobblestones for the pattern.

Edge_Soften: Softens the edge of the cobblestones.

Middle_Size: Sqishes-pulls every other cobblestone.

Cobblestone_Scale: Controls the overal size of the cobblestones.

Slope_Variation: Adds random sloping to the cobblestones.

Cobblestone_Scale_Variation: Gives some variation to the size of all of the cobblestones.

Interstice: sets the gap size between the cobblestones.

---------------------------------------------------------------------------------
Dirt
---------------------------------------------------------------------------------

Dirt_Height: increasing the value will bring the dirt almost flush with the tops of the cobblestones, decreasing the value will push it back.

Dirt Tamper:  Secondary control that works in tandem with Dirt Height.

Dirt_Level: Controls how much dirt covers the cobble stones.

Dirt_Contrast: Contrast control for the Dirt_Level control


=================================================================================
MODULAR STONEWALL
=================================================================================


Normal Intensity: Controls the strength of the normal map.

---------------------------------------------------------------------------------
Color
---------------------------------------------------------------------------------
3 color pickers for the stones

1 color picker for the plaster

1 color picker for Dirt

Stone Highlight Lightness: Controls the intensity of the stone highlights in the diffuse.

Stone Highlight Range: Controls the spread of the stone highlight.

Stone Highlight Contrast: Secondary control that works with Stone Highlight Range.

Stone Secondary Highlight Opacity: Controls the strength of a secondary highlight.

-----------------------------------------------------------------------------------
Pattern
-----------------------------------------------------------------------------------
Pattern Switch: switches between 4 different patterns.

-----------------------------------------------------------------------------------
Straight Pattern
-----------------------------------------------------------------------------------

Stone Shape Switch: Changes the base stone shape used in the pattern.

Number X: Number of stones in a row.

Number Y: Number of rows in the pattern.

Straight Pattern Rotation Random: Rotates each stone in a random direction.

Edge Soften: Makes the stone less sharp.

Middle Size: Shape variation control for the stone shapes in each row.

Stone Scale: Controls the overall size of the stones.

Shape Breakup: adds imperfections to the stone shapes.

Slope Variation: Adds more veriety to the stone shapes.

Height Varieation: Varies the height of each stone in the pattern.

Stone Scale Variation: Varies the size of each of the stones.

Interstice: More shape controls for the lenght and width of the stones.

--------------------------------------------------------------------------------------
Irregular Pattern
--------------------------------------------------------------------------------------

Roght or Smooth Stones: Switches between rough and smooth stones.

X and Y amount: Controls the number of stones.

Offset: offsets the stones.

Split and Split 2: splits the stones in the pattern to make different patterns.

Random Slope Rotation: Rotates the sloping that's applied to the stone shapes.

Irregular Stone Scale: Controls the overall size of the stones.

Size Random X and Y: Randomizes the stone sizes.

Edge Roundness: Controls how round the edges of the stones are.

Color Variation Random Seed: Randomizes the color variation on the pattern.

---------------------------------------------------------------------------------------
Flat Stone
---------------------------------------------------------------------------------------

Flat Stone Holes Size: Changes the size of rough chunks in the stone.

Flat Stone Holes Depth: Controls the depth of the rough chunks in the stone.

Flat Stone Holes Pattern Scale: Controls the size of the rough chunk pattern.

Flat Stone Holes Random Seed: Randomizes the hole pattern.

----------------------------------------------------------------------------------------
Row Stone
----------------------------------------------------------------------------------------
Number of Cuts: Controls the number of verticle cuts.

Crack Breakup: Adds irregularity to the cracks.

Stone Roughness variation Scale: Controls the scale of the pattern used for making the stone rough.

-----------------------------------------------------------------------------------------
Plaster
-----------------------------------------------------------------------------------------

Rough or flat: Rough textured plaster or tampered flat.

Plaster Thickness: Controls the thickness of the plaster between the stones.

Plaster Thickness Contrast: Secondary control for Plaster Thickness.

Plaster Blur: Blurs the mask that for where the plaster shows up.

Plaster Height: Controls the height of the plaster.

Stone Height: Controls the height of the stones.

Plaster Med Detail Scale: Controls the scale of a pattern used for roughing up the texture of the plaster.

Plaster Med Detail Blur: Blurs the pattern used in Plaster Med Detail Scale.

Plaster Micro Detail Strength: Controls the strength of a micro detail pattern that further roughs up the plaster.

-----------------------------------------------------------------------------------------------
Dirt
-----------------------------------------------------------------------------------------------

Dirt Level: Controls the spread of dirt on the material.

Dirt Contrast: Secondary control for Dirt Level.

Grunge Amount: Controls the amount of dirt that shows up on the material.

Edges Masking: Controls the spread on dirt on the edges.

================================================================================================
Modular Wood
================================================================================================


------------------------------------------------------------------------------------------------
Wood
------------------------------------------------------------------------------------------------

Wood or Wood Rings: Switches between wood or wood ends.

Wood Planks: bare wood or planks.

Nails On Off: Turns nails on off.

Number of Planks: Number of wood planks on the material.

Wood Knots On Off: Turns on off knots in the wood.

Wood Color: Color picker.

Wood Cracks Intensity: Controls the depth of the cracks in the wood.

-------------------------------------------------------------------------------------------------
Dirt
-------------------------------------------------------------------------------------------------

Dirt Saturation: Controls the saturation of the dirt color in the diffuse.

Dirt Luminosity: Controls the lightness of the dirt color in the diffuse.

Dirt Hue: Changes the Hue of the dirt color in the diffuse.

Dirt Level: Controls the spread of dirt on the material.

Dirt Contrast: Secondary control for controling the spread of dirt.

Grundge Amount: Control the amount of dirt.

-------------------------------------------------------------------------------------------------
Paint
-------------------------------------------------------------------------------------------------

Paint Color: Color picker.

Paint Mask Slider: Controls the paint coverage on the material.

Paint Mask Contrast: Secondary control for controling the coverage of paint on the material.

===================================================================================================
WOOD SHINGLES
===================================================================================================

---------------------------------------------------------------------------------------------------
Shingles
---------------------------------------------------------------------------------------------------

X Amount: Controls the number of Shingles on a row.

Y Amount: Controls the number of rows of shingles.

Shingle_Cracks_Intensity: Controls the intensity of the wood cracks on the shingles.

Rotation: Changes the direction of the shingles.

Length_Width: Controls the size of the shingles.

Size_Random: Randomizes the length and width of the shingles.

Scale: Controls the overall scale of the shingles.

----------------------------------------------------------------------------------------------------
Wood Color
----------------------------------------------------------------------------------------------------

Shingles Color: Color picker.

Ambient_Occlusion_Intensity: Controls the intensity of Ambient Occlusion on the diffuse.

----------------------------------------------------------------------------------------------------
Paint
----------------------------------------------------------------------------------------------------

Paint_Color: Color picker for the paint.

Paint_Range: Controls how far down the paint covers each shingle from the top to bottom.

Paint_Contrast: Controls the contrast of the paint on the shingles.

Paint_slider: Controls how much paint is on the shingles.

-----------------------------------------------------------------------------------------------------
Dirt
-----------------------------------------------------------------------------------------------------
Dirt Color: Color picker.

Dirt Level: Controls the spread of the dirt.

Dirt Contrast: Secondary control for controlling the spread of dirt.

Grundge Amount: Controls the amount of dirt.

------------------------------------------------------------------------------------------------------
Shingles Offset
------------------------------------------------------------------------------------------------------

Shingles_Offset: Controls the offset of the shingles.

Shingles_Offset_Type: Controls which direction that the shingles are offset.

Shingles_Displacement_Intensity: Spreads out the shingles in an irregualr pattern.

------------------------------------------------------------------------------------------------------
Base Shape
------------------------------------------------------------------------------------------------------

Base_Shape_Switch: switches between 3 different shapes for the shingles.

Base_Shape_Skew: Can skew the shingle shape to the left or right.

Base_Shape_Gradient_Slider: Controls the shape of the shingle.











